from pathlib import Path

path = Path('/home/ubuntu/mailsentinel/client/src/pages/Home.tsx')
lines = path.read_text().splitlines()
replacement = '''function RouteMap({ hops }: { hops: Hop[] }) { const [mapFailed, setMapFailed] = useState(false); const routeHops = hops.filter(hop => hop.kind === "public" && Number.isFinite(hop.lat) && Number.isFinite(hop.lng)); const center = routeHops[0] ?? { lat: 20, lng: 0 }; return <div className="relative overflow-hidden rounded-2xl border border-white/10 bg-[#07121f]"><MapView className="h-[310px]" hops={hops} initialCenter={center} initialZoom={routeHops.length > 1 ? 2 : 1} onMapError={() => setMapFailed(true)} /><div className="pointer-events-none absolute left-4 top-4 z-20 rounded-lg border border-white/10 bg-[#07121f]/90 px-3 py-2 text-[11px] text-cyan-100 backdrop-blur"><div className="flex items-center gap-2"><Globe2 className="h-3.5 w-3.5" /> {mapFailed ? "Map unavailable · fallback context" : "Interactive world map · red route"}</div><div className="mt-1 text-slate-400">Observed routing context · not sender attribution</div></div>{mapFailed && <div className="pointer-events-none absolute inset-x-4 bottom-4 z-20 rounded-lg border border-amber-300/20 bg-[#07121f]/95 px-3 py-2 text-[11px] text-amber-100">Leaflet could not initialize. The observed hop cards remain the source of truth; no sender location is inferred.</div>}{!mapFailed && routeHops.length < 2 && <div className="pointer-events-none absolute inset-x-4 bottom-4 z-20 rounded-lg border border-white/10 bg-[#07121f]/90 px-3 py-2 text-[11px] text-slate-300">{routeHops.length === 1 ? "One validated public IP coordinate observed; a multi-hop red route needs at least two points." : "No validated public-IP coordinates available; private, reserved, and synthetic hops are excluded from geolocation."}</div>}</div>; }'''
for index, line in enumerate(lines):
    if line.startswith('function RouteMap('):
        lines[index] = replacement
        break
else:
    raise SystemExit('RouteMap function not found')
path.write_text('\n'.join(lines) + '\n')
