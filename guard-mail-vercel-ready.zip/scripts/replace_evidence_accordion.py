from pathlib import Path

path = Path('/home/ubuntu/mailsentinel/client/src/pages/Home.tsx')
text = path.read_text()
text = text.replace('import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";\n', '')
start = text.find('<Accordion type="multiple">')
end = text.find('</Accordion>', start)
if start < 0 or end < 0:
    raise SystemExit('accordion block not found')
replacement = '''<div className="space-y-2">{analysis.result.evidence.map(item => <details key={item.id} className="group rounded-xl border border-white/10 bg-[#07121f]"><summary className="flex cursor-pointer list-none items-center gap-3 p-3 text-left marker:content-none"><span className="font-mono text-xs text-cyan-300">{item.id}</span><span className="min-w-0 flex-1 truncate text-sm text-slate-100">{item.observation}</span><Badge className={severityClass[item.severity] ?? severityClass.medium}>{item.severity}</Badge><ChevronRight className="h-4 w-4 shrink-0 text-slate-500 transition-transform group-open:rotate-90" /></summary><div className="grid gap-2 border-t border-white/10 p-4 text-xs text-slate-300 md:grid-cols-2"><p><strong className="text-slate-100">Source:</strong> {item.source}</p><p><strong className="text-slate-100">Confidence:</strong> {Math.round(item.confidence * 100)}%</p><p><strong className="text-slate-100">Interpretation:</strong> {item.interpretation}</p><p><strong className="text-slate-100">Impact:</strong> {item.impact}</p><p className="md:col-span-2"><strong className="text-slate-100">Recommended action:</strong> {item.recommended_action}</p></div></details>)}</div>'''
text = text[:start] + replacement + text[end + len('</Accordion>'):]
path.write_text(text)
