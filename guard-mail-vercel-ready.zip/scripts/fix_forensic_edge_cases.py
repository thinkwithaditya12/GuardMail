from pathlib import Path

path = Path('/home/ubuntu/mailsentinel/server/routers.ts')
lines = path.read_text().splitlines()
new_attachment_line = r'''function extractBase64Attachment(text: string, name: string) { const escaped = name.replace(/[.*+?^${}()|[\]\\]/g, "\\$&"); const match = text.match(new RegExp(`(?:filename|name)=['"]?${escaped}['"]?[\\s\\S]{0,500}?Content-Transfer-Encoding:\\s*base64[\\s\\S]{0,200}?[\\n\\r]{2}([A-Za-z0-9+/=\\s]{8,})`, "i")); if (!match?.[1]) return null; const encoded = match[1].split(/--[A-Za-z0-9'=_-]+/)[0].replace(/\\s/g, ""); try { const bytes = Buffer.from(encoded, "base64"); return bytes.length > 0 && bytes.length <= 2_000_000 ? bytes : null; } catch { return null; } }'''
for index, line in enumerate(lines):
    if line.startswith('function extractBase64Attachment('):
        lines[index] = new_attachment_line
        break
else:
    raise SystemExit('attachment helper not found')
text = '\n'.join(lines) + '\n'
old = ': rules.score >= 35 ? "suspicious" : rules.score >= 18 || rules.uncertaintyReasons.length > 1 ? "inconclusive" : "safe";'
new = ': rules.score >= 35 ? "suspicious" : rules.score >= 18 || (rules.flags.financial_request && rules.flags.missing_authentication) ? "inconclusive" : "safe";'
if old not in text:
    raise SystemExit('classification expression not found')
path.write_text(text.replace(old, new, 1))
