import { and, desc, eq, like } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import { InsertUser, scans, InsertScan, users } from "../drizzle/schema";
import { ENV } from "./_core/env";

let _db: ReturnType<typeof drizzle> | null = null;

export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) throw new Error("User openId is required for upsert");
  const db = await getDb();
  if (!db) return;
  const values: InsertUser = { openId: user.openId };
  const updateSet: Record<string, unknown> = {};
  const textFields = ["name", "email", "loginMethod"] as const;
  for (const field of textFields) {
    if (user[field] !== undefined) {
      values[field] = user[field] ?? null;
      updateSet[field] = user[field] ?? null;
    }
  }
  values.lastSignedIn = user.lastSignedIn ?? new Date();
  updateSet.lastSignedIn = values.lastSignedIn;
  if (user.role) {
    values.role = user.role;
    updateSet.role = user.role;
  } else if (user.openId === ENV.ownerOpenId) {
    values.role = "admin";
    updateSet.role = "admin";
  }
  await db.insert(users).values(values).onDuplicateKeyUpdate({ set: updateSet });
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);
  return result[0];
}

export async function createScan(scan: InsertScan) {
  const db = await getDb();
  if (!db) return undefined;
  await db.insert(scans).values(scan);
  const result = await db.select().from(scans).where(eq(scans.reportId, scan.reportId)).limit(1);
  return result[0];
}

export async function listScans(userId: number, query?: string) {
  const db = await getDb();
  if (!db) return [];
  const conditions = query?.trim()
    ? and(eq(scans.userId, userId), like(scans.summary, `%${query.trim()}%`))
    : eq(scans.userId, userId);
  return db.select().from(scans).where(conditions).orderBy(desc(scans.createdAt)).limit(50);
}

export async function getScanById(userId: number, id: number) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(scans).where(and(eq(scans.userId, userId), eq(scans.id, id))).limit(1);
  return result[0];
}

export async function deleteScan(userId: number, id: number) {
  const db = await getDb();
  if (!db) return false;
  await db.delete(scans).where(and(eq(scans.userId, userId), eq(scans.id, id)));
  return true;
}
