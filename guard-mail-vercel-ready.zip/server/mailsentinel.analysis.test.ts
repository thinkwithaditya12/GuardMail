import { describe, expect, it } from "vitest";
import { analyzeAttachments, analyzeUrls, appRouter, fallbackResult, interpretQuery, isPublicIPv4, parseAuthentication, parseEmail, scoreRules } from "./routers";
import type { TrpcContext } from "./_core/context";

describe("MailSentinel analysis primitives", () => {
  const suspicious = `From: Billing Support <support@paypa1-alerts.com>\nReply-To: recovery@other.example\nSubject: URGENT verify your account now\nAuthentication-Results: spf=fail; dmarc=fail\nReceived: from relay (203.0.113.24)\n\nPlease login immediately and verify your password at https://bit.ly/check`;

  it("parses headers, public IPs, URLs, and body without executing content", () => {
    const parsed = parseEmail(suspicious);
    expect(parsed.headers.from).toContain("paypa1-alerts.com");
    expect(parsed.ips).toEqual([]);
    expect(parsed.observedIps).toEqual(["203.0.113.24"]);
    expect(parsed.urls).toEqual(["https://bit.ly/check"]);
    expect(parsed.body).toContain("verify your password");
  });

  it("detects multiple red flags with a transparent score", () => {
    const score = scoreRules(parseEmail(suspicious));
    expect(score.score).toBeGreaterThan(20);
    expect(score.flags.urgent_language).toBe(true);
    expect(score.flags.credential_request).toBe(true);
    expect(score.flags.shortened_url).toBe(true);
  });

  it("excludes private and reserved IPv4 addresses from geolocation", () => {
    expect(isPublicIPv4("8.8.8.8")).toBe(true);
    expect(isPublicIPv4("203.0.113.24")).toBe(false);
    expect(isPublicIPv4("10.0.0.8")).toBe(false);
    expect(isPublicIPv4("192.168.1.5")).toBe(false);
    expect(isPublicIPv4("127.0.0.1")).toBe(false);
  });

  it("keeps a rules-based fallback available when live analysis is unavailable", () => {
    const score = scoreRules(parseEmail(suspicious));
    expect(score.score).toBeGreaterThan(20);
    expect(score.flags.credential_request).toBe(true);
  });

  it("blocks unauthenticated access to protected scan history", async () => {
    const ctx: TrpcContext = { user: null, req: {} as TrpcContext["req"], res: {} as TrpcContext["res"] };
    const caller = appRouter.createCaller(ctx);
    await expect(caller.scans.list()).rejects.toMatchObject({ code: "UNAUTHORIZED" });
  });

  it("parses authentication statuses and preserves unavailable states", () => {
    expect(parseAuthentication({ "authentication-results": "spf=fail; dkim=pass; dmarc=none" })).toMatchObject({ spf: "FAIL", dkim: "PASS", dmarc: "NONE", available: true });
    expect(parseAuthentication({}).spf).toBe("NOT AVAILABLE IN SUPPLIED EMAIL");
  });

  it("analyzes URL structure without opening the URL", () => {
    const finding = analyzeUrls(["https://xn--bcher-kva.example/login?next=1"])[0];
    expect(finding?.punycode).toBe(true);
    expect(finding?.suspiciousPatterns).toContain("credential-themed path");
    expect(finding?.protocol).toBe("https");
  });

  it("handles malformed .eml input without opening content or crashing", () => {
    const parsed = parseEmail("this is not a valid RFC email and contains no headers");
    expect(parsed.headers).toEqual({});
    expect(parsed.body).toBe("");
    expect(parsed.urls).toEqual([]);
  });

  it("computes a safe attachment hash and signature when base64 bytes are present", () => {
    const parsed = parseEmail("Content-Type: multipart/mixed; boundary=mail\n\n--mail\nContent-Disposition: attachment; filename=report.pdf\nContent-Transfer-Encoding: base64\n\nJVBERi0xLjQK\n--mail--");
    const finding = analyzeAttachments(parsed)[0];
    expect(finding?.signature).toBe("PDF (%PDF)");
    expect(finding?.sha256).toMatch(/^[a-f0-9]{64}$/);
    expect(finding?.byteLength).toBeGreaterThan(0);
  });

  it("flags executable-like attachment metadata without executing it", () => {
    const parsed = parseEmail("Content-Type: application/octet-stream; name=invoice.pdf.exe\n\nBody");
    const finding = analyzeAttachments(parsed)[0];
    expect(finding?.executable).toBe(true);
    expect(finding?.sha256).toContain("Unavailable");
  });

  it("classifies a benign message as safe when evidence is complete and quiet", () => {
    const parsed = parseEmail("From: Library <library@university.example>\nTo: student@example.com\nSubject: Reserved book ready\nAuthentication-Results: spf=pass; dkim=pass; dmarc=pass\n\nYour reserved book is ready.");
    const result = fallbackResult(parsed, scoreRules(parsed));
    expect(result.primary_label).toBe("safe");
  });

  it("classifies a suspicious attachment as malware-risk evidence without claiming execution", () => {
    const parsed = parseEmail("From: Payroll <payroll@company.example>\nSubject: Statement\nContent-Disposition: attachment; filename=statement.pdf.exe\n\nReview the attachment.");
    const result = fallbackResult(parsed, scoreRules(parsed));
    expect(result.primary_label).toBe("malware_malicious_attachment");
    expect(result.evidence.some(item => item.indicator === "attachment_metadata")).toBe(true);
  });

  it("produces an inconclusive result for incomplete mixed evidence", () => {
    const parsed = parseEmail("From: Finance <finance@vendor.example>\nSubject: Updated payment details\n\nPlease confirm the bank account for the next invoice.");
    const result = fallbackResult(parsed, scoreRules(parsed));
    expect(result.primary_label).toBe("inconclusive");
    expect(result.limitations.some(item => item.includes("authentication headers unavailable"))).toBe(true);
  });

  it("interprets permitted history query fields without exposing raw email content", () => {
    const interpretation = interpretQuery("Show high-risk phishing emails from suspicious Russian IPs last week");
    expect(interpretation.category).toBe("likely_phishing");
    expect(interpretation.country).toBe("RU");
    expect(interpretation.riskOnly).toBe(true);
    expect(interpretation.explanation).toContain("not sender attribution");
  });
});
