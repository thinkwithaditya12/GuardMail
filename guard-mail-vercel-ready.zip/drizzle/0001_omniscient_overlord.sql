CREATE TABLE `scans` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`reportId` varchar(48) NOT NULL,
	`senderMasked` varchar(320),
	`subjectMasked` varchar(320),
	`primaryLabel` varchar(64) NOT NULL,
	`riskScore` int NOT NULL,
	`confidence` int NOT NULL,
	`summary` text NOT NULL,
	`findingsJson` text NOT NULL,
	`hopsJson` text NOT NULL,
	`headersJson` text NOT NULL,
	`inputHash` varchar(64) NOT NULL,
	`isSynthetic` int NOT NULL DEFAULT 0,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `scans_id` PRIMARY KEY(`id`),
	CONSTRAINT `scans_reportId_unique` UNIQUE(`reportId`)
);
--> statement-breakpoint
ALTER TABLE `users` MODIFY COLUMN `role` varchar(16) NOT NULL DEFAULT 'user';