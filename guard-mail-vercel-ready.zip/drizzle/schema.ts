import { int, mysqlTable, text, timestamp, varchar } from "drizzle-orm/mysql-core";

export const users = mysqlTable("users", {
  id: int("id").autoincrement().primaryKey(),
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: varchar("role", { length: 16 }).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export const scans = mysqlTable("scans", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  reportId: varchar("reportId", { length: 48 }).notNull().unique(),
  senderMasked: varchar("senderMasked", { length: 320 }),
  subjectMasked: varchar("subjectMasked", { length: 320 }),
  primaryLabel: varchar("primaryLabel", { length: 64 }).notNull(),
  riskScore: int("riskScore").notNull(),
  confidence: int("confidence").notNull(),
  summary: text("summary").notNull(),
  findingsJson: text("findingsJson").notNull(),
  hopsJson: text("hopsJson").notNull(),
  headersJson: text("headersJson").notNull(),
  inputHash: varchar("inputHash", { length: 64 }).notNull(),
  isSynthetic: int("isSynthetic").default(0).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;
export type Scan = typeof scans.$inferSelect;
export type InsertScan = typeof scans.$inferInsert;
